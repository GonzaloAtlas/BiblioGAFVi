package com.biblioGAFVi.BiblioGAFVi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiblioGafViApplicationTests {

	@Test
	void contextLoads() {
	}

}
